#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"
#include "StudentWorld.h"

class StudentWorld;

class Actor : public GraphObject {
public:
	Actor(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* world);
	StudentWorld* returnWorld();
	virtual ~Actor();
	bool isAlive() {
		return m_isAlive; 
	}
	void setAliveStatus(bool status) {
		m_isAlive = status; 
	}
	virtual bool canOverlap() const {
		return true; 
	}
	virtual bool getBonked() const{
		return true; 
	}
	virtual bool damagable() const{
		return false; 
	}
	virtual void doSomething() = 0;
private:
	StudentWorld* m_studentWorld;
	bool m_isAlive = true;

};

class Flag : public Actor { //fix cuz should be able to overlap flag
public:
	Flag(int imageID, int startX, int startY, StudentWorld* world);
	
	virtual ~Flag();
	void doSomething();
private:
};

class Mario : public Flag { //fix cuz should be able to overlap flag
public:
	Mario(int imageID, int startX, int startY, StudentWorld* world);
	virtual ~Mario();
	void doSomething();
private:
};

class Pipe : public Actor {
public:
	Pipe(int imageID, int startX, int startY, StudentWorld* world);
	virtual bool canOverlap() const {
		return false;
	}
	virtual ~Pipe();
	void doSomething();
private:
};

class Block : public Pipe {
public:
	Block(int imageID, int startX, int startY, StudentWorld* world);
	virtual ~Block();
	void doSomething();
private:
};

class Enemy : public Actor {
public:
	Enemy(int imageID, int startX, int startY, StudentWorld* world);
	virtual bool canOverlap() const {
		return false;
	}
	virtual ~Enemy();
	void doSomething();
private:
};

class Goomba : public Enemy {
public:
	Goomba(int imageID, int startX, int startY, StudentWorld* world);
	virtual ~Goomba();
	void doSomething();
private:
};

class Koopa : public Enemy {
public:
	Koopa(int imageID, int startX, int startY, StudentWorld* world);
	virtual ~Koopa();
	void doSomething();
private:
};

class Peach : public Actor {
public:
	Peach(int startX, int startY, StudentWorld* world);
	virtual ~Peach();
	void doSomething();
private:
	int hitPoint = 1;
	bool noTempInvincibility = false;
	bool hasStar = false;
	bool hasShoot = false;
	bool hasJump = false;
};


#endif // ACTOR_H_



