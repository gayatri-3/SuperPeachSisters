#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include "Level.h"
#include <string>

#include <sstream>
#include <iomanip>

#include <list>
#include "Actor.h"

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp

class GraphObject;
class Peach;
class Actor;

class StudentWorld : public GameWorld
{
public:
	StudentWorld(std::string assetPath);
	virtual ~StudentWorld();
	virtual int init();
	virtual int move();
	virtual void cleanUp();
	
	Peach* getPeach() {
		return m_peach; 
	}
	virtual bool getCompleteLevel() const {
		return m_completeLevel;
	}
	void setCompleteLevel(bool status) {
		m_completeLevel = status; 
	}
	virtual bool overlapPeach(int X, int Y, bool& overlap,  Actor* ptr);
	virtual void displayGameText();
	virtual void gravity(Actor* ptr); 

private:
	Peach* m_peach;
	std::list<Actor*> m_actors;
	bool m_completeLevel = false; 

};

#endif // STUDENTWORLD_H_





