
#include "Actor.h"

using namespace std;

//changes to heirarcy-- moving and stationary main subclasses. peach and enemy under moving one

Actor::Actor(int imageID, int startX, int startY, int dir, int depth, double size, StudentWorld* world) :
    GraphObject(imageID, startX, startY, dir, depth, size) {
    m_studentWorld = world;
}


StudentWorld* Actor::returnWorld() {
    return m_studentWorld;
}

Actor::~Actor() {
    ;
}



Flag::Flag(int imageID, int startX, int startY, StudentWorld* world)
    : Actor(imageID, startX, startY, 0, 1, 1.0, world) {
    ;
}

Flag::~Flag() {
    ;
}

void Flag::doSomething() {
    if (isAlive()) {
        bool isOverlaping = false;
        if (returnWorld()->getPeach()->getX() == getX() && returnWorld()->getPeach()->getY() == getY())
        {
            setAliveStatus(false);
            cerr << "dead flag" << endl;
            returnWorld()->increaseScore(1000);
            returnWorld()->setCompleteLevel(true);
            //NEXT: inform completed level
        }
    }
}



Mario::Mario(int imageID, int startX, int startY, StudentWorld* world)
    : Flag(IID_MARIO, startX, startY, world) {
    ;
}

Mario::~Mario() {
    ;
}

void Mario::doSomething() {
    ;
}



Pipe::Pipe(int imageID, int startX, int startY, StudentWorld* world)
    : Actor(imageID, startX, startY, 0, 2, 1.0, world) {
    ;
}

Pipe::~Pipe() {
    ;
}

void Pipe::doSomething() {
    ;
}



Block::Block(int ImageID, int startX, int startY, StudentWorld* world)
    : Pipe(IID_BLOCK, startX, startY, world) {
    ;
}

Block::~Block() {
    ;
}

void Block::doSomething() {
    ;
}



Enemy::Enemy(int imageID, int startX, int startY, StudentWorld* world)
    : Actor(imageID, startX, startY, 0, 2, 1.0, world) {
    ;
}

Enemy::~Enemy() {
    ;
}

void Enemy::doSomething() {
    ;
}

Goomba::Goomba(int ImageID, int startX, int startY, StudentWorld* world)
    : Enemy(IID_GOOMBA, startX, startY, world) {
    ;
}

Goomba::~Goomba() {
    ;
}

void Goomba::doSomething() {
    int key;
    if (isAlive()) {
        bool isOverlaping = false;
        //cerr << "alive" << endl;
        if (getDirection() == 0) {
            if (!returnWorld()->overlapPeach(getX() - 1, getY(), isOverlaping, this)) {
                cerr << "move left" << endl;
                moveTo(getX() - 1, getY());
               
            }
            else {
                cerr << "done left" << endl;
                setDirection(180);
            }
            
        }
        if (getDirection() == 180)  {
            if (!returnWorld()->overlapPeach(getX() + 1, getY(), isOverlaping, this)) {
                cerr << "move right" << endl;
                moveTo(getX() + 1, getY());
                
            }
            else {
                cerr << "done right" << endl;
                setDirection(0);
            }
           
        }

    }
}


Koopa::Koopa(int ImageID, int startX, int startY, StudentWorld* world)
    : Enemy(IID_KOOPA, startX, startY, world) {
    ;
}

Koopa::~Koopa() {
    ;
}

void Koopa::doSomething() {
    ;
}


Peach::Peach(int startX, int startY, StudentWorld* world) :
    Actor(IID_PEACH, startX, startY, 0, 0, 1.0, world) {
    ;
}

Peach::~Peach() {
    ;
}

void Peach::doSomething() {
    int key;
    if (isAlive()) {
        if (returnWorld()->getKey(key)) {
            switch (key) {
                bool isOverlaping;
            case KEY_PRESS_LEFT:
                setDirection(180);
                if (!returnWorld()->overlapPeach(getX() - 4, getY(), isOverlaping, this)) {
                    moveTo(getX() - 4, getY());
                }
                break;
            case KEY_PRESS_RIGHT:
                setDirection(0);
                if (!returnWorld()->overlapPeach(getX() + 4, getY(), isOverlaping, this)) {
                    moveTo(getX() + 4, getY());
                }
                break;
            case KEY_PRESS_UP:
                returnWorld()->playSound(SOUND_PLAYER_JUMP);
                if (!returnWorld()->overlapPeach(getX(), getY() + 4, isOverlaping, this)) {
                    moveTo(getX(), getY() + 4);
                }
                break;
            case KEY_PRESS_DOWN:
                returnWorld()->playSound(SOUND_PLAYER_JUMP);
                if (!returnWorld()->overlapPeach(getX(), getY() - 4, isOverlaping, this)) {
                    moveTo(getX(), getY() - 4);
                }
                break;
            case KEY_PRESS_SPACE:
                returnWorld()->playSound(SOUND_PLAYER_FIRE);
                break;
            }
        }
    }
}









