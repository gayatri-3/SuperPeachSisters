#include "StudentWorld.h"
#include "GameConstants.h"
#include <string>
using namespace std;

#include "GraphObject.h"


GameWorld* createStudentWorld(string assetPath)
{
    return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h, and Actor.cpp

StudentWorld::StudentWorld(string assetPath)
    : GameWorld(assetPath)
{
}

StudentWorld::~StudentWorld() {
    cleanUp();
}

int StudentWorld::init()
{
    Level lev(assetPath());
    ostringstream oss;
    oss << getLevel();
    string s = oss.str();
    string level_file = "level0" + s + ".txt";
    Level::LoadResult result = lev.loadLevel(level_file);
    if (result == Level::load_fail_file_not_found)
        cerr << "Could not find level01.txt data file" << endl;

    else if (result == Level::load_fail_bad_format)
        cerr << "level01.txt is improperly formatted" << endl;

    else if (result == Level::load_success)
    {
        cerr << "Successfully loaded level" << endl;
        Level::GridEntry ge;
        for (int x = 0; x < 32; x++)
            for (int y = 0; y < 32; y++)
            {
                ge = lev.getContentsOf(x, y);
                switch (ge)
                {
                case Level::peach:
                    m_peach = new Peach(x * SPRITE_WIDTH, y * SPRITE_HEIGHT, this);
                    break;

                case Level::block:
                    m_actors.push_back(new Block(IID_BLOCK, x * SPRITE_WIDTH, y * SPRITE_HEIGHT, this));
                    break;

                case Level::pipe:
                    m_actors.push_back(new Pipe(IID_PIPE, x * SPRITE_WIDTH, y * SPRITE_HEIGHT, this));
                    break;

                case Level::flag:
                    m_actors.push_back(new Flag(IID_FLAG, x * SPRITE_WIDTH, y * SPRITE_HEIGHT, this));
                    break;

                case Level::mario:
                    m_actors.push_back(new Mario(IID_MARIO, x * SPRITE_WIDTH, y * SPRITE_HEIGHT, this));
                    break;

                case Level::goomba:
                    m_actors.push_back(new Goomba(IID_GOOMBA, x * SPRITE_WIDTH, y * SPRITE_HEIGHT, this));
                    break;

                case Level::koopa:
                    m_actors.push_back(new Koopa(IID_KOOPA, x * SPRITE_WIDTH, y * SPRITE_HEIGHT, this));
                    break;
                }
            }
    }


    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move()
{
    displayGameText();
     
    if (m_peach->isAlive()) {
        m_peach->doSomething();
    //    gravity(m_peach);
    }

    list<Actor*>::iterator it;
    it = m_actors.begin();
    while ((it) != m_actors.end()) {
        if ((*it)->isAlive()) {
            (*it)->doSomething();
            //if it can move, use gravity 

            if (!m_peach->isAlive()) {
                playSound(SOUND_PLAYER_DIE);
                return GWSTATUS_PLAYER_DIED;
            }

            if (getCompleteLevel()) {
                setCompleteLevel(false);
                return GWSTATUS_FINISHED_LEVEL;
            }
        }
        it++;
    }

//    displayGameText();

    //decLives();
    return GWSTATUS_CONTINUE_GAME;
}


void StudentWorld::displayGameText() {
    ostringstream oss; 
    oss << "Lives: " << getLives();
    oss << setw(10) <<  " Level: ";
    oss.fill('0');
    oss << setw(2) << getLevel();
    oss.fill(' ');
    oss << setw(10) << " Points: ";
    oss.fill('0');
    oss << setw(6) << getScore();
    string s = oss.str(); 
    setGameStatText(s);
}

void StudentWorld::gravity(Actor* ptr) {
    list<Actor*>::iterator it;
    it = m_actors.begin();
    while (it != m_actors.end() && ptr != *it) {
        cerr << "true" << endl;
        /*bool overlap = false; 
        if (!overlapPeach(ptr->getX(), ptr->getY()-4, overlap, ptr) && !overlap) {
            ptr->moveTo(ptr->getX(), ptr->getY() - 4);
        }*/
    }
}

bool StudentWorld::overlapPeach(int X, int Y, bool& overlap, Actor* ptr) {
    //!(*it)->canOverlap() means it prevents overlap
    list<Actor*>::iterator it;
    it = m_actors.begin();
    while (it != m_actors.end()) {

        if ((* it) == ptr) { //if they are the same item, then return false becasue want the item to still move
            cerr << "is itself" << endl;
            return false; 
        }

        //bottomLeft
        if ((*it)->getX() >= X && (*it)->getX() <= (X + SPRITE_WIDTH - 1) &&
            (*it)->getY() >= Y && (*it)->getY() <= (Y + SPRITE_HEIGHT - 1)
            ) {

            if (!(*it)->canOverlap()) {
                return true;
            }
            else {
                overlap = true;
            }
        }

        ////bottomRight
        if ((*it)->getX() + SPRITE_WIDTH - 1 >= X && (*it)->getX() + SPRITE_WIDTH - 1 <= (X + SPRITE_WIDTH - 1) &&
            (*it)->getY() >= Y && (*it)->getY() <= (Y + SPRITE_HEIGHT - 1)
            ) {
            if (!(*it)->canOverlap()) {
                return true;
            }
            else {
                overlap = true;
            }
        }

        ////topRight
        if ((*it)->getX() >= X && (*it)->getX() <= (X + SPRITE_WIDTH - 1) &&
            (*it)->getY() + SPRITE_HEIGHT - 1 >= Y && (*it)->getY() + SPRITE_HEIGHT - 1 <= (Y + SPRITE_HEIGHT - 1)
            ) {
            if (!(*it)->canOverlap()) {
                return true;
            }
            else {
                overlap = true;
            }
        }

        ////topLeft
        if ((*it)->getX() + SPRITE_WIDTH - 1 >= X && (*it)->getX() + SPRITE_WIDTH - 1 <= (X + SPRITE_WIDTH - 1) &&
            (*it)->getY() + SPRITE_HEIGHT - 1 >= Y && (*it)->getY() + SPRITE_HEIGHT - 1 <= (Y + SPRITE_HEIGHT - 1)
            ) {
            if (!(*it)->canOverlap()) {
                return true;
            }
            else {
                overlap = true;
            }
        }

        it++;
    }
    //returns true if overlap exists between peach and something blockable 
    //returns false if overlap doesn't exist or if overlap exists between peach and something that doesn't block 
    return false;
}


void StudentWorld::cleanUp()
{
    //iterate through actor list and delete each one
    list<Actor*>::iterator it;
    it = m_actors.begin();

    while (it != m_actors.end()) {
        delete* it;
        it = m_actors.erase(it);
    }

    delete m_peach;
}





